export default {
  volcano: {
    apiKey: '7c35b307-eeed-4554-a4e3-7172069e0db7',
    endpointId: 'ep-20260219144721-gp58q',
    baseUrl: 'https://ark.cn-beijing.volces.com/api/v3/chat/completions'
  }
}
